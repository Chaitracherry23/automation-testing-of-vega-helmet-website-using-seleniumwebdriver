from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
import time

# Path to ChromeDriver
service = Service(executable_path="chromedriver.exe")
driver = webdriver.Chrome(service=service)

def search_vega_helmet_website(driver):
    driver.get('https://www.google.com')
    search_box = driver.find_element(By.NAME, "q")
    search_box.send_keys("Vega Helmet website")
    search_box.send_keys(Keys.RETURN)
    time.sleep(2)
    
    first_result = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, '(//h3)[1]/../../a'))
    )
    first_result.click()
    time.sleep(5)

def accept_cookies(driver):
    try:
        accept_cookies_button = WebDriverWait(driver, 6).until(
            EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Accept All Cookies")]'))
        )
        accept_cookies_button.click()
    except Exception as e:
        print("No cookie prompt found.")

def login(driver, username, password):
    driver.find_element(By.XPATH, "/html/body/div[2]/header/nav/div/div[2]/a[1]").click()
    time.sleep(2)

    email_input = driver.find_element(By.XPATH, "/html/body/div[2]/main/div/article/div/div/div/div[3]/div[2]/div[1]/form/p[1]/input")
    email_input.click()
    email_input.send_keys(username)
    time.sleep(2)

    password_input = driver.find_element(By.XPATH, "/html/body/div[2]/main/div/article/div/div/div/div[3]/div[2]/div[1]/form/span/input")
    password_input.click()
    password_input.send_keys(password)
    time.sleep(2)

    driver.find_element(By.XPATH, "/html/body/div[2]/main/div/article/div/div/div/div[3]/div[2]/div[1]/form/p[4]/button").click()
    time.sleep(2)

def navigate_to_accessories_category(driver):
    driver.get('https://vegaauto.com/category/accessories/')
    time.sleep(2)

def navigate_to_product_page(driver):
    driver.get('https://vegaauto.com/product/bolt-yellow-visor/')
    time.sleep(2)

def add_to_cart(driver):
    add_to_cart_button = driver.find_element(By.XPATH, '//button[@name="add-to-cart" and @value="77574"]')
    driver.execute_script("arguments[0].scrollIntoView(true);", add_to_cart_button)
    time.sleep(2)
    add_to_cart_button.click()
    time.sleep(6)

def navigate_to_cart_page(driver):
    driver.get('https://vegaauto.com/cart/')
    time.sleep(6)

try:
    driver.maximize_window()
    
    search_vega_helmet_website(driver)
    
    accept_cookies(driver)

    login(driver, "dayanandaob@gmail.com", "Dayananda@456")

    navigate_to_accessories_category(driver)
    navigate_to_product_page(driver)
    add_to_cart(driver)
    navigate_to_cart_page(driver)

    # Navigate back to the home page
    driver.get('https://vegaauto.com/')
    time.sleep(7)

    # Scroll down to the bottom of the home page
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(7)

    # Scroll back up to the top of the home page
    driver.execute_script("window.scrollTo(0, 0);")
    time.sleep(7)

    # Click on Contact Us
    contact_us_button = driver.find_element(By.XPATH, '//a[contains(text(), "Contact Us")]')
    contact_us_button.click()
    time.sleep(7)

    # Scroll down to the bottom of the Contact Us page
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(7)

    # Scroll back up to the top of the Contact Us page
    driver.execute_script("window.scrollTo(0, 0);")
    time.sleep(7)
    
    #click on vega care page
    vega_care_button = driver.find_element(By.XPATH,'//*[@id="menu-item-34930"]/a')
    vega_care_button.click()
    time.sleep(7)
    
    #add to wishlist in vega care
    wishlist_button = driver.find_element(By.XPATH,'//*[@id="primary"]/div[3]/ul/li/div/div/a/i')
    wishlist_button.click()
    time.sleep(7)
    

    # Return to the home page
    driver.get('https://vegaauto.com/')
    time.sleep(7)

finally:
    driver.quit()
